#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int check;
    int check1;
    int amount;
    do {
        amount = get_int("Amount? ");
    }
    while(amount < 1);
    for(check = 0;check<amount;)
    {
        check++;
        for(check1 = (amount-check);check1>0;check1--)
        {
            printf(" ");
        }
        for(check1 = check;check1>0;check1--)
        {
            printf("#");
        }
        printf("  ");
        for(check1 = check;check1>0;check1--)
        {
            printf("#");
        }

        printf("\n");

    }
}
